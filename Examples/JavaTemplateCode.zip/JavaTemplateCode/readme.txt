CS4551 Multimedia Software Systems
@ Author: Elaine Kang
Computer Science Department
California State University, Los Angeles

Compile requirement
======================================
JDK Version 7.0 or above


Compile Instruction on Command Line:
======================================
javac CS4551_Main.java Image.java 
or 
javac *.java


Execution Instruction on Command Line:
======================================
java CS4551_Main [inputfile]
e.g.
java CS4551_Main Ducky.ppm 